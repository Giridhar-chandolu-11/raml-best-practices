### Version 0.0.0
  - Initial Template 
    - Updated by: Max Girin- 2021-01-28
### Version 1.0.0
  - Initial RAML
  - Updated by: Max Girin - 2021-02-22
### Version 1.0.1
  - Changed customerMeasures endpoint to indirectCustomerMappings
  - Updated by: Max Girin - 2021-02-23
### Version 1.0.2
  - Updated documentation
  - Updated by: Max Girin - 2021-02-23


### Published History
---
- Asset Version: **1.0.0**
- Published By: **Max Girin**
- Date / Time: **2021-02-22 at 1900**
---
- Asset Version: **1.0.1**
- Published By: **Max Girin**
- Date / Time: **2021-02-23 at 1400**
---
- Asset Version: **1.0.2**
- Published By: **Max Girin**
- Date / Time: **2021-02-23 at 1500**
---