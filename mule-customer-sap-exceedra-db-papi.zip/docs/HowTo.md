# **Clorox Enterprise Customer Process API**
---
### **How To Use The API?**
- HTTPs GET, POST methods will be used for **mule sap system api**.
###### *Details of the Methods:*
- **/ping:/GET** Get API Status.
- **/ping:/POST** Post API Status.
- **/customerAttributes:/POST** This operation is to pick up the list of customer attributes and transform into Exceedra DB JSON request.
- **/customerAttributes/job/start:/POST** This operation is to manually kick off the scheduled job to start the customer attributes data flow into Exceedra DB database.
- **/customerHierarchies:/POST** This operation is to pick up the list of customer hierarchies and transform into Exceedra DB JSON request.
- **/customerHierarchies/job/start:/POST** This operation is to manually kick off the scheduled job to start the customer hierarchies data flow into Exceedra DB database.
- **/indirectCustomerMappings:/POST** This operation is to pick up the list of indirect customer mappings and transform into Exceedra DB JSON request.
- **/indirectCustomerMappings/job/start:/POST** This operation is to manually kick off the scheduled job to start the indirect customer mappings data flow into Exceedra DB database.